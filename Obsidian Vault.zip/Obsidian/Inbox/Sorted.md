---
sorting-spec: |
  // ::::: ROOT :::::
  target-folder: /*
  /:files
  > a-z by-metadata: Created
  /:folders
   Reminders & Tasks
   Wunderlist
   Calendar
   Books & Articles
   Inbox
   Read Later
   Library
   Highlights
   Studyblr
   Writing & Dialy
   Tumblr
   Substack
   Journal
   Slowly
   Uncategorized
   Templates & Config
   Attachments
   Archived
   Others
  %

  // ::::: READ LATER :::::
  target-folder: Read Later/
  /:files
  > a-z by-metadata: Created
  %
  /folders

  // ::::: INBOX :::::
  target-folder: Inbox/
  /:folders
  /:files.md
  < a-z by-metadata: Created
  %

  // ::::: BOOKS :::::
  target-folder: Library/Bookshelfs
  > a-z
---